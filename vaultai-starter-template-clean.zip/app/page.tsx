export default function Home() {
  return (
    <main>
      <h1>VaultAI</h1>
      <a href="/bot">Zum Bot</a>
    </main>
  );
}
