'use client';
import { useState } from 'react';

export default function BotPage() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');

  const handleAsk = () => {
    setResponse(`Analysiere: ${input}`);
  };

  return (
    <main>
      <h1>Vault Bot</h1>
      <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Chart/Token" />
      <button onClick={handleAsk}>Analyse starten</button>
      {response && <p>{response}</p>}
    </main>
  );
}
